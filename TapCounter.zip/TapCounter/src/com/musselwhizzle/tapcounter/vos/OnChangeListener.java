package com.musselwhizzle.tapcounter.vos;

public interface OnChangeListener<T> {
	void onChange(T model);
}
